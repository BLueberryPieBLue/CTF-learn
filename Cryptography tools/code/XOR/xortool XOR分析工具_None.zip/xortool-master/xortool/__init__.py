#!/usr/bin/env python
#-*- coding:utf-8 -*-

__all__ = ["args", "colors", "libcolors", "routine"]
__version__ = "0.96"
