/*
 * Extender.cpp
 *
 *  Created on: Aug 29, 2012
 *      Author: bwall
 */

#include "Extender.h"

Extender::Extender() {
	// TODO Auto-generated constructor stub

}

Extender::~Extender() {
	// TODO Auto-generated destructor stub
}

